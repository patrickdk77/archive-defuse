a plain file in a tar archive
