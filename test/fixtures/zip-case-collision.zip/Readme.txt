Readme.txt holds plain text.
