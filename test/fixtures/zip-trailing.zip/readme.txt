readme.txt holds plain text.
